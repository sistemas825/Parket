import { query } from "./_generated/server";
import { v } from "convex/values";
import type { Id, Doc } from "./_generated/dataModel.d.ts";

export const stockSummary = query({
  args: {},
  handler: async (ctx) => {
    const products = await ctx.db.query("products").withIndex("by_active", (q) => q.eq("active", true)).collect();

    const totalProducts = products.length;
    const lowStock = products.filter((p) => p.minStock != null && p.currentStock <= p.minStock).length;
    const zeroStock = products.filter((p) => p.currentStock === 0).length;

    const totalClients = await ctx.db.query("clients").collect().then((c) => c.length);

    return { totalProducts, lowStock, zeroStock, totalClients };
  },
});

export const movementsByType = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const days = args.days ?? 30;
    const since = Date.now() - days * 24 * 60 * 60 * 1000;

    const movements = await ctx.db.query("stockMovements").order("desc").collect();
    const recent = movements.filter((m) => m._creationTime >= since);

    const byType: Record<string, number> = {};
    for (const m of recent) {
      byType[m.type] = (byType[m.type] ?? 0) + 1;
    }

    return byType;
  },
});

export const ordersByStatus = query({
  args: {},
  handler: async (ctx) => {
    const orders = await ctx.db.query("orders").collect();
    const byStatus: Record<string, number> = {};
    for (const o of orders) {
      byStatus[o.status] = (byStatus[o.status] ?? 0) + 1;
    }
    return byStatus;
  },
});

export const ordersByStatusAndClient = query({
  args: {
    status: v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado"),
    ),
  },
  handler: async (ctx, args) => {
    const orders = await ctx.db
      .query("orders")
      .withIndex("by_status", (q) => q.eq("status", args.status))
      .order("desc")
      .collect();

    // Group by client
    const clientMap: Record<string, { clientName: string; clientCity?: string; orders: { orderNumber: string; _id: Id<"orders">; _creationTime: number }[] }> = {};

    await Promise.all(
      orders.map(async (o) => {
        const client = await ctx.db.get(o.clientId);
        const key = o.clientId;
        if (!clientMap[key]) {
          clientMap[key] = {
            clientName: client?.name ?? "—",
            clientCity: client?.city,
            orders: [],
          };
        }
        clientMap[key].orders.push({ orderNumber: o.orderNumber, _id: o._id, _creationTime: o._creationTime });
      })
    );

    return Object.values(clientMap).sort((a, b) => b.orders.length - a.orders.length);
  },
});

export const topMovedProducts = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const days = args.days ?? 30;
    const since = Date.now() - days * 24 * 60 * 60 * 1000;

    const movements = await ctx.db.query("stockMovements").order("desc").collect();
    const recent = movements.filter((m) => m._creationTime >= since);

    const productMap: Record<string, { entries: number; exits: number; productId: string }> = {};
    for (const m of recent) {
      const id = m.productId;
      if (!productMap[id]) productMap[id] = { entries: 0, exits: 0, productId: id };
      if (m.quantity > 0) productMap[id].entries += m.quantity;
      else productMap[id].exits += Math.abs(m.quantity);
    }

    const sorted = Object.values(productMap)
      .sort((a, b) => (b.entries + b.exits) - (a.entries + a.exits))
      .slice(0, 10);

    return await Promise.all(
      sorted.map(async (item) => {
        const product = await ctx.db.get(item.productId as Id<"products">);
        return {
          ...item,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          currentStock: product?.currentStock ?? 0,
        };
      })
    );
  },
});

export const freightByClient = query({
  args: {},
  handler: async (ctx) => {
    const orders = await ctx.db.query("orders").collect();

    // Aggregate freight per client (exclude cancelled and retirada)
    const clientMap: Record<string, { clientName: string; clientCity?: string; total: number; count: number }> = {};

    await Promise.all(
      orders
        .filter((o) => o.status !== "cancelado" && o.freightType !== "retirada" && (o.freightValue ?? 0) > 0)
        .map(async (o) => {
          const client = await ctx.db.get(o.clientId);
          const key = o.clientId;
          if (!clientMap[key]) {
            clientMap[key] = {
              clientName: client?.name ?? "—",
              clientCity: client?.city,
              total: 0,
              count: 0,
            };
          }
          clientMap[key].total += o.freightValue ?? 0;
          clientMap[key].count += 1;
        })
    );

    return Object.values(clientMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 20);
  },
});

export const recentMovementsList = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const days = args.days ?? 7;
    const since = Date.now() - days * 24 * 60 * 60 * 1000;
    const movements = await ctx.db.query("stockMovements").order("desc").collect();
    const recent = movements.filter((m) => m._creationTime >= since).slice(0, 50);

    return await Promise.all(
      recent.map(async (m) => {
        const product = await ctx.db.get(m.productId);
        return {
          ...m,
          productName: product?.name ?? "—",
          productUnit: product?.unit ?? "un",
        };
      })
    );
  },
});

// Full orders with client info and items for detailed PDF report
export const ordersFullReport = query({
  args: {
    status: v.optional(v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado"),
    )),
  },
  handler: async (ctx, args): Promise<{
    _id: Id<"orders">;
    orderNumber: string;
    status: string;
    freightType: string;
    freightValue?: number;
    notes?: string;
    deliveryAddress?: string;
    scheduledDate?: string;
    deliveredAt?: string;
    _creationTime: number;
    client: { name: string; phone?: string; city?: string; state?: string; address?: string };
    items: { productName: string; productCode: string; quantity: number; unit: string; unitPrice?: number }[];
    totalItems: number;
    totalValue: number;
  }[]> => {
    const orders = args.status
      ? await ctx.db.query("orders").withIndex("by_status", (q) => q.eq("status", args.status!)).order("desc").collect()
      : await ctx.db.query("orders").order("desc").collect();

    return await Promise.all(
      orders.map(async (o) => {
        const client = await ctx.db.get(o.clientId);
        const orderItems = await ctx.db.query("orderItems").withIndex("by_order", (q) => q.eq("orderId", o._id)).collect();
        const items = await Promise.all(
          orderItems.map(async (item) => {
            const product = await ctx.db.get(item.productId);
            return {
              productName: product?.name ?? "—",
              productCode: product?.code ?? "—",
              quantity: item.quantity,
              unit: product?.unit ?? "un",
              unitPrice: item.unitPrice,
            };
          })
        );
        const totalValue = items.reduce((s, i) => s + (i.unitPrice ?? 0) * i.quantity, 0);
        return {
          _id: o._id,
          orderNumber: o.orderNumber,
          status: o.status,
          freightType: o.freightType,
          freightValue: o.freightValue,
          notes: o.notes,
          deliveryAddress: o.deliveryAddress,
          scheduledDate: o.scheduledDate,
          deliveredAt: o.deliveredAt,
          _creationTime: o._creationTime,
          client: {
            name: client?.name ?? "—",
            phone: client?.phone,
            city: client?.city,
            state: client?.state,
            address: client?.address,
          },
          items,
          totalItems: items.length,
          totalValue,
        };
      })
    );
  },
});

// Inventory report data
export const inventoryReport = query({
  args: {},
  handler: async (ctx): Promise<{
    _id: Id<"inventories">;
    name: string;
    status: string;
    notes?: string;
    finishedAt?: string;
    _creationTime: number;
    items: {
      productName: string;
      productCode: string;
      unit: string;
      expectedQuantity: number;
      countedQuantity?: number;
      difference?: number;
      notes?: string;
    }[];
    totalItems: number;
    countedItems: number;
    divergentItems: number;
  }[]> => {
    const inventories = await ctx.db.query("inventories").order("desc").collect();
    return await Promise.all(
      inventories.map(async (inv) => {
        const rawItems = await ctx.db.query("inventoryItems").withIndex("by_inventory", (q) => q.eq("inventoryId", inv._id)).collect();
        const items = await Promise.all(
          rawItems.map(async (item) => {
            const product = await ctx.db.get(item.productId);
            return {
              productName: product?.name ?? "—",
              productCode: product?.code ?? "—",
              unit: product?.unit ?? "un",
              expectedQuantity: item.expectedQuantity,
              countedQuantity: item.countedQuantity,
              difference: item.difference,
              notes: item.notes,
            };
          })
        );
        return {
          _id: inv._id,
          name: inv.name,
          status: inv.status,
          notes: inv.notes,
          finishedAt: inv.finishedAt,
          _creationTime: inv._creationTime,
          items,
          totalItems: items.length,
          countedItems: items.filter((i) => i.countedQuantity != null).length,
          divergentItems: items.filter((i) => i.difference != null && i.difference !== 0).length,
        };
      })
    );
  },
});

// Orders grouped by client with full details
export const ordersByClient = query({
  args: {
    clientId: v.optional(v.id("clients")),
    status: v.optional(v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado"),
    )),
  },
  handler: async (ctx, args): Promise<{
    clientId: string;
    clientName: string;
    clientPhone?: string;
    clientEmail?: string;
    clientCity?: string;
    clientState?: string;
    clientAddress?: string;
    clientDocument?: string;
    totalOrders: number;
    totalValue: number;
    totalFreight: number;
    orders: {
      _id: string;
      orderNumber: string;
      status: string;
      freightType: string;
      freightValue?: number;
      notes?: string;
      deliveryAddress?: string;
      scheduledDate?: string;
      deliveredAt?: string;
      _creationTime: number;
      items: { productName: string; productCode: string; quantity: number; unit: string; unitPrice?: number; subtotal: number }[];
      totalItems: number;
      totalValue: number;
    }[];
  }[]> => {
    let orders: Doc<"orders">[] = [];

    if (args.clientId) {
      orders = await ctx.db.query("orders").withIndex("by_client", (q) => q.eq("clientId", args.clientId!)).order("desc").collect();
    } else {
      orders = await ctx.db.query("orders").order("desc").collect();
    }

    if (args.status) {
      orders = orders.filter((o) => o.status === args.status);
    }

    // Group by client
    const clientMap: Record<string, {
      clientId: string;
      clientName: string;
      clientPhone?: string;
      clientEmail?: string;
      clientCity?: string;
      clientState?: string;
      clientAddress?: string;
      clientDocument?: string;
      totalOrders: number;
      totalValue: number;
      totalFreight: number;
      orders: {
        _id: string;
        orderNumber: string;
        status: string;
        freightType: string;
        freightValue?: number;
        notes?: string;
        deliveryAddress?: string;
        scheduledDate?: string;
        deliveredAt?: string;
        _creationTime: number;
        items: { productName: string; productCode: string; quantity: number; unit: string; unitPrice?: number; subtotal: number }[];
        totalItems: number;
        totalValue: number;
      }[];
    }> = {};

    await Promise.all(
      orders.map(async (o) => {
        const client = (await ctx.db.get(o.clientId)) as Doc<"clients"> | null;
        const key = o.clientId as string;
        if (!clientMap[key]) {
          clientMap[key] = {
            clientId: key,
            clientName: client?.name ?? "—",
            clientPhone: client?.phone,
            clientEmail: client?.email,
            clientCity: client?.city,
            clientState: client?.state,
            clientAddress: client?.address,
            clientDocument: client?.document,
            totalOrders: 0,
            totalValue: 0,
            totalFreight: 0,
            orders: [],
          };
        }
        const orderItems = await ctx.db.query("orderItems").withIndex("by_order", (q) => q.eq("orderId", o._id)).collect();
        const items = await Promise.all(
          orderItems.map(async (item) => {
            const product = (await ctx.db.get(item.productId)) as Doc<"products"> | null;
            const subtotal = (item.unitPrice ?? 0) * item.quantity;
            return {
              productName: product?.name ?? "—",
              productCode: product?.code ?? "—",
              quantity: item.quantity,
              unit: product?.unit ?? "un",
              unitPrice: item.unitPrice,
              subtotal,
            };
          })
        );
        const orderValue = items.reduce((s, i) => s + i.subtotal, 0);
        clientMap[key].totalOrders += 1;
        clientMap[key].totalValue += orderValue;
        clientMap[key].totalFreight += o.freightValue ?? 0;
        clientMap[key].orders.push({
          _id: o._id as string,
          orderNumber: o.orderNumber,
          status: o.status,
          freightType: o.freightType,
          freightValue: o.freightValue,
          notes: o.notes,
          deliveryAddress: o.deliveryAddress,
          scheduledDate: o.scheduledDate,
          deliveredAt: o.deliveredAt,
          _creationTime: o._creationTime,
          items,
          totalItems: items.length,
          totalValue: orderValue,
        });
      })
    );

    return Object.values(clientMap).sort((a, b) => b.totalOrders - a.totalOrders);
  },
});

// Report: stock exits (saidas) grouped by product and period
export const saidaMaterialReport = query({
  args: { days: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const days = args.days ?? 30;
    const since = Date.now() - days * 24 * 60 * 60 * 1000;

    const movements = await ctx.db
      .query("stockMovements")
      .withIndex("by_type", (q) => q.eq("type", "saida"))
      .order("desc")
      .collect();

    const recent = movements.filter((m) => m._creationTime >= since);

    // Group by product
    const productMap: Record<
      string,
      {
        productId: string;
        productName: string;
        productCode: string;
        unit: string;
        totalQty: number;
        movCount: number;
        lastDate: number;
        exits: {
          date: number;
          qty: number;
          reason: string | undefined;
          orderNumber: string | undefined;
        }[];
      }
    > = {};

    await Promise.all(
      recent.map(async (m) => {
        const product = await ctx.db.get(m.productId);
        const key = m.productId;

        // Fetch order number if linked
        let orderNumber: string | undefined;
        if (m.orderId) {
          const order = await ctx.db.get(m.orderId);
          orderNumber = order?.orderNumber;
        }

        if (!productMap[key]) {
          productMap[key] = {
            productId: key,
            productName: product?.name ?? "—",
            productCode: product?.code ?? "—",
            unit: product?.unit ?? "un",
            totalQty: 0,
            movCount: 0,
            lastDate: 0,
            exits: [],
          };
        }

        const qty = Math.abs(m.quantity);
        productMap[key].totalQty += qty;
        productMap[key].movCount += 1;
        if (m._creationTime > productMap[key].lastDate) {
          productMap[key].lastDate = m._creationTime;
        }
        productMap[key].exits.push({
          date: m._creationTime,
          qty,
          reason: m.reason,
          orderNumber,
        });
      })
    );

    const rows = Object.values(productMap).sort((a, b) => b.totalQty - a.totalQty);

    const totalExits = rows.reduce((s, r) => s + r.movCount, 0);
    const totalQty = rows.reduce((s, r) => s + r.totalQty, 0);

    return { rows, totalExits, totalQty, days };
  },
});

export const toolTransportsSummary = query({
  args: {},
  handler: async (ctx) => {
    const transports = await ctx.db.query("toolTransports").collect();

    const byStatus: Record<string, number> = {};
    for (const t of transports) {
      byStatus[t.status] = (byStatus[t.status] ?? 0) + 1;
    }

    // Aggregate freight per client
    const clientMap: Record<string, { clientName: string; clientCity?: string; total: number; count: number }> = {};
    await Promise.all(
      transports
        .filter((t) => t.status !== "cancelado" && (t.freightValue ?? 0) > 0)
        .map(async (t) => {
          const client = await ctx.db.get(t.clientId);
          const key = t.clientId;
          if (!clientMap[key]) {
            clientMap[key] = {
              clientName: client?.name ?? "—",
              clientCity: client?.city,
              total: 0,
              count: 0,
            };
          }
          clientMap[key].total += t.freightValue ?? 0;
          clientMap[key].count += 1;
        })
    );

    const freightByClient = Object.values(clientMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 20);

    return {
      total: transports.length,
      byStatus,
      freightByClient,
    };
  },
});
