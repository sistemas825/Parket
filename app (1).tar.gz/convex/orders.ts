import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import { paginationOptsValidator } from "convex/server";

// Generate next order number
export const getNextOrderNumber = query({
  args: {},
  handler: async (ctx) => {
    const last = await ctx.db.query("orders").order("desc").first();
    if (!last) return "PED-0001";
    const match = last.orderNumber.match(/\d+$/);
    const next = match ? parseInt(match[0]) + 1 : 1;
    return `PED-${String(next).padStart(4, "0")}`;
  },
});

export const listOrders = query({
  args: {
    paginationOpts: paginationOptsValidator,
    status: v.optional(v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado")
    )),
  },
  handler: async (ctx, args) => {
    const base = args.status
      ? ctx.db.query("orders").withIndex("by_status", (q) => q.eq("status", args.status!))
      : ctx.db.query("orders");

    const result = await base.order("desc").paginate(args.paginationOpts);

    const page = await Promise.all(
      result.page.map(async (order) => {
        const client = await ctx.db.get(order.clientId);
        const items = await ctx.db
          .query("orderItems")
          .withIndex("by_order", (q) => q.eq("orderId", order._id))
          .collect();
        const itemCount = items.length;
        return { ...order, clientName: client?.name ?? "—", clientPhone: client?.phone, clientCity: client?.city, itemCount };
      })
    );
    return { ...result, page };
  },
});

export const getOrder = query({
  args: { id: v.id("orders") },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.id);
    if (!order) return null;
    const client = await ctx.db.get(order.clientId);
    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", args.id))
      .collect();
    const itemsWithProduct = await Promise.all(
      items.map(async (item) => {
        const product = await ctx.db.get(item.productId);
        return {
          ...item,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          m2PerBox: product?.m2PerBox,
        };
      })
    );
    const photos = await ctx.db
      .query("orderPhotos")
      .withIndex("by_order", (q) => q.eq("orderId", args.id))
      .collect();
    return { ...order, client, items: itemsWithProduct, photos };
  },
});

export const createOrder = mutation({
  args: {
    clientId: v.id("clients"),
    orderNumber: v.string(),
    freightType: v.union(v.literal("interno"), v.literal("terceiro"), v.literal("retirada")),
    freightValue: v.optional(v.number()),
    notes: v.optional(v.string()),
    deliveryAddress: v.optional(v.string()),
    scheduledDate: v.optional(v.string()),
    items: v.array(v.object({
      productId: v.id("products"),
      quantity: v.number(),
      unitPrice: v.optional(v.number()),
      notes: v.optional(v.string()),
    })),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const { items, ...orderData } = args;
    const orderId = await ctx.db.insert("orders", {
      ...orderData,
      status: "confirmado",
      createdBy: user._id,
    });

    for (const item of items) {
      await ctx.db.insert("orderItems", { orderId, ...item });

      // Descontar estoque do produto automaticamente
      const product = await ctx.db.get(item.productId);
      if (product) {
        const quantityBefore = product.currentStock;
        const quantityAfter = quantityBefore - item.quantity;
        await ctx.db.patch(item.productId, { currentStock: quantityAfter });
        await ctx.db.insert("stockMovements", {
          productId: item.productId,
          type: "saida",
          quantity: -item.quantity,
          quantityBefore,
          quantityAfter,
          reason: `Pedido ${args.orderNumber}`,
          orderId,
          createdBy: user._id,
        });
      }
    }

    return orderId;
  },
});

export const updateOrderStatus = mutation({
  args: {
    id: v.id("orders"),
    status: v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado")
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const order = await ctx.db.get(args.id);
    if (!order) throw new ConvexError({ message: "Pedido não encontrado", code: "NOT_FOUND" });

    const patch: Record<string, unknown> = { status: args.status, updatedBy: user._id };
    if (args.status === "entregue") patch.deliveredAt = new Date().toISOString();

    await ctx.db.patch(args.id, patch);

    // When cancelling, return stock for all items (only if it was previously deducted)
    // Stock is deducted when order moves from rascunho to confirmado/em_separacao/etc.
    // So if the old status was NOT rascunho, stock must be returned.
    if (args.status === "cancelado" && order.status !== "cancelado" && order.status !== "rascunho") {
      const items = await ctx.db
        .query("orderItems")
        .withIndex("by_order", (q) => q.eq("orderId", args.id))
        .collect();

      for (const item of items) {
        const product = await ctx.db.get(item.productId);
        if (!product) continue;
        const quantityBefore = product.currentStock;
        const quantityAfter = quantityBefore + item.quantity;
        await ctx.db.patch(item.productId, { currentStock: quantityAfter });
        await ctx.db.insert("stockMovements", {
          productId: item.productId,
          type: "entrada",
          quantity: item.quantity,
          quantityBefore,
          quantityAfter,
          reason: `Cancelamento do Pedido ${order.orderNumber}`,
          orderId: args.id,
          createdBy: user._id,
        });
      }
    }
  },
});

export const updateOrder = mutation({
  args: {
    id: v.id("orders"),
    clientId: v.optional(v.id("clients")),
    freightType: v.optional(v.union(v.literal("interno"), v.literal("terceiro"), v.literal("retirada"))),
    freightValue: v.optional(v.number()),
    notes: v.optional(v.string()),
    deliveryAddress: v.optional(v.string()),
    scheduledDate: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

export const addOrderItem = mutation({
  args: {
    orderId: v.id("orders"),
    productId: v.id("products"),
    quantity: v.number(),
    unitPrice: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    return await ctx.db.insert("orderItems", args);
  },
});

export const removeOrderItem = mutation({
  args: { id: v.id("orderItems") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.id);
  },
});

// Public query — no auth required, used for shareable order link
export const getOrderPublic = query({
  args: { id: v.id("orders") },
  handler: async (ctx, args) => {
    const order = await ctx.db.get(args.id);
    if (!order) return null;
    const client = await ctx.db.get(order.clientId);
    const items = await ctx.db
      .query("orderItems")
      .withIndex("by_order", (q) => q.eq("orderId", args.id))
      .collect();
    const itemsWithProduct = await Promise.all(
      items.map(async (item) => {
        const product = await ctx.db.get(item.productId);
        return {
          ...item,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          m2PerBox: product?.m2PerBox,
        };
      })
    );
    const photos = await ctx.db
      .query("orderPhotos")
      .withIndex("by_order", (q) => q.eq("orderId", args.id))
      .collect();
    const photosWithUrl = await Promise.all(
      photos.map(async (photo) => {
        const url = await ctx.storage.getUrl(photo.storageId);
        return { ...photo, url };
      })
    );
    const signature = await ctx.db
      .query("orderSignatures")
      .withIndex("by_order", (q) => q.eq("orderId", args.id))
      .first();
    return {
      orderNumber: order.orderNumber,
      status: order.status,
      freightType: order.freightType,
      freightValue: order.freightValue,
      notes: order.notes,
      deliveryAddress: order.deliveryAddress,
      scheduledDate: order.scheduledDate,
      deliveredAt: order.deliveredAt,
      creationTime: order._creationTime,
      clientName: client?.name ?? "—",
      clientCity: client?.city,
      clientPhone: client?.phone,
      items: itemsWithProduct,
      photos: photosWithUrl,
      signature: signature
        ? { signerName: signature.signerName, signatureData: signature.signatureData, signedAt: signature.signedAt }
        : null,
    };
  },
});

// Search orders by order number or client name (searches all orders, not paginated)
export const searchOrders = query({
  args: { search: v.string() },
  handler: async (ctx, args) => {
    const q = args.search.toLowerCase().trim();
    if (!q) return [];

    // Find clients matching the search
    const allClients = await ctx.db.query("clients").collect();
    const matchingClientIds = new Set(
      allClients
        .filter((c) => c.name.toLowerCase().includes(q))
        .map((c) => c._id)
    );

    // Fetch all orders and filter by order number or matching client
    const allOrders = await ctx.db.query("orders").order("desc").collect();
    const matched = allOrders.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        matchingClientIds.has(o.clientId)
    );

    return await Promise.all(
      matched.map(async (order) => {
        const client = await ctx.db.get(order.clientId);
        const items = await ctx.db
          .query("orderItems")
          .withIndex("by_order", (q) => q.eq("orderId", order._id))
          .collect();
        return {
          ...order,
          clientName: client?.name ?? "—",
          clientPhone: client?.phone,
          clientCity: client?.city,
          itemCount: items.length,
        };
      })
    );
  },
});

// Public list — no auth required, for the shareable orders tracking page
export const listOrdersPublic = query({
  args: {
    search: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Array<{
    _id: string;
    orderNumber: string;
    status: string;
    freightType: string;
    creationTime: number;
    scheduledDate: string | undefined;
    clientName: string;
    clientCity: string | undefined;
    itemCount: number;
  }>> => {
    const orders = await ctx.db.query("orders").order("desc").collect();

    const withClient = await Promise.all(
      orders.map(async (o) => {
        const client = await ctx.db.get(o.clientId);
        const items = await ctx.db
          .query("orderItems")
          .withIndex("by_order", (q) => q.eq("orderId", o._id))
          .collect();
        return {
          _id: o._id as string,
          orderNumber: o.orderNumber,
          status: o.status,
          freightType: o.freightType,
          creationTime: o._creationTime,
          scheduledDate: o.scheduledDate,
          clientName: client?.name ?? "—",
          clientCity: client?.city,
          itemCount: items.length,
        };
      })
    );

    if (!args.search) return withClient;
    const q = args.search.toLowerCase();
    return withClient.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        o.clientName.toLowerCase().includes(q)
    );
  },
});
