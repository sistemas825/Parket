import { query, mutation } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.d.ts";
import type { MutationCtx, QueryCtx } from "./_generated/server";

// ─── Helpers ───────────────────────────────────────────────────────────────

async function requireUser(ctx: MutationCtx | QueryCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });
  return user;
}

// ─── Vehicles ──────────────────────────────────────────────────────────────

export const listVehicles = query({
  args: {
    status: v.optional(v.union(v.literal("disponivel"), v.literal("em_uso"), v.literal("manutencao"))),
    type: v.optional(v.union(v.literal("carro"), v.literal("caminhao"), v.literal("van"), v.literal("moto"))),
  },
  handler: async (ctx, args) => {
    let vehicles = await ctx.db
      .query("vehicles")
      .withIndex("by_active", (q) => q.eq("active", true))
      .collect();
    if (args.status) vehicles = vehicles.filter((v) => v.status === args.status);
    if (args.type) vehicles = vehicles.filter((v) => v.type === args.type);
    return vehicles;
  },
});

export const getVehicle = query({
  args: { id: v.id("vehicles") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const createVehicle = mutation({
  args: {
    plate: v.string(),
    model: v.string(),
    brand: v.string(),
    year: v.optional(v.number()),
    type: v.union(v.literal("carro"), v.literal("caminhao"), v.literal("van"), v.literal("moto")),
    color: v.optional(v.string()),
    currentKm: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    // Check duplicate plate (only among active vehicles)
    const existing = await ctx.db
      .query("vehicles")
      .withIndex("by_plate", (q) => q.eq("plate", args.plate.toUpperCase()))
      .filter((q) => q.eq(q.field("active"), true))
      .first();
    if (existing) throw new ConvexError({ message: "Placa já cadastrada", code: "CONFLICT" });
    return await ctx.db.insert("vehicles", {
      ...args,
      plate: args.plate.toUpperCase(),
      status: "disponivel",
      active: true,
      createdBy: user._id,
    });
  },
});

export const updateVehicle = mutation({
  args: {
    id: v.id("vehicles"),
    plate: v.optional(v.string()),
    model: v.optional(v.string()),
    brand: v.optional(v.string()),
    year: v.optional(v.number()),
    type: v.optional(v.union(v.literal("carro"), v.literal("caminhao"), v.literal("van"), v.literal("moto"))),
    color: v.optional(v.string()),
    status: v.optional(v.union(v.literal("disponivel"), v.literal("em_uso"), v.literal("manutencao"))),
    currentKm: v.optional(v.number()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...fields } = args;
    const patch: Partial<typeof fields> & { plate?: string } = { ...fields };
    if (patch.plate) patch.plate = patch.plate.toUpperCase();
    await ctx.db.patch(id, patch);
  },
});

export const deleteVehicle = mutation({
  args: { id: v.id("vehicles") },
  handler: async (ctx, args) => {
    await ctx.db.patch(args.id, { active: false });
  },
});

// ─── Vehicle Usage ──────────────────────────────────────────────────────────

export const listUsage = query({
  args: {
    vehicleId: v.optional(v.id("vehicles")),
    status: v.optional(v.union(v.literal("aberto"), v.literal("concluido"))),
    driverName: v.optional(v.string()),
    dateFrom: v.optional(v.string()), // YYYY-MM-DD
    dateTo: v.optional(v.string()),   // YYYY-MM-DD
  },
  handler: async (ctx, args) => {
    let rows: Doc<"vehicleUsage">[];
    if (args.vehicleId) {
      rows = await ctx.db
        .query("vehicleUsage")
        .withIndex("by_vehicle", (q) => q.eq("vehicleId", args.vehicleId as Id<"vehicles">))
        .order("desc")
        .collect();
    } else {
      rows = await ctx.db.query("vehicleUsage").order("desc").collect();
    }
    if (args.status) rows = rows.filter((r) => r.status === args.status);
    if (args.driverName) {
      const needle = args.driverName.toLowerCase();
      rows = rows.filter((r) => r.driverName.toLowerCase().includes(needle));
    }
    if (args.dateFrom) rows = rows.filter((r) => r.departureDate >= args.dateFrom!);
    if (args.dateTo) rows = rows.filter((r) => r.departureDate <= args.dateTo!);
    // Attach vehicle info
    const vehicles = await Promise.all(rows.map((r) => ctx.db.get(r.vehicleId)));
    return rows.map((r, i) => ({ ...r, vehicle: vehicles[i] }));
  },
});

export const getUsage = query({
  args: { id: v.id("vehicleUsage") },
  handler: async (ctx, args) => {
    const usage = await ctx.db.get(args.id);
    if (!usage) return null;
    const vehicle = await ctx.db.get(usage.vehicleId);
    return { ...usage, vehicle };
  },
});

export const createUsage = mutation({
  args: {
    vehicleId: v.id("vehicles"),
    driverName: v.string(),
    destination: v.optional(v.string()),
    purpose: v.optional(v.string()),
    departureDate: v.string(),
    departureTime: v.string(),
    kmDeparture: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    // Mark vehicle as in use
    await ctx.db.patch(args.vehicleId, { status: "em_uso" });
    return await ctx.db.insert("vehicleUsage", {
      ...args,
      status: "aberto",
      createdBy: user._id,
    });
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const getUsagePhotoUrls = query({
  args: { storageIds: v.array(v.string()) },
  handler: async (ctx, args) => {
    const urls = await Promise.all(
      args.storageIds.map((id) => ctx.storage.getUrl(id as `${string}`))
    );
    return urls.filter((u): u is string => u !== null);
  },
});

export const closeUsage = mutation({
  args: {
    id: v.id("vehicleUsage"),
    arrivalDate: v.string(),
    arrivalTime: v.string(),
    kmArrival: v.number(),
    fuelCost: v.optional(v.number()),
    damages: v.optional(v.string()),
    damagePhotoIds: v.optional(v.array(v.string())),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, kmArrival, ...rest } = args;
    const usage = await ctx.db.get(id);
    if (!usage) throw new ConvexError({ message: "Registro não encontrado", code: "NOT_FOUND" });
    const kmDriven = kmArrival - usage.kmDeparture;
    await ctx.db.patch(id, {
      ...rest,
      kmArrival,
      kmDriven,
      status: "concluido",
    });
    // Update vehicle km and status
    await ctx.db.patch(usage.vehicleId, {
      currentKm: kmArrival,
      status: "disponivel",
    });
  },
});

export const updateUsage = mutation({
  args: {
    id: v.id("vehicleUsage"),
    driverName: v.optional(v.string()),
    destination: v.optional(v.string()),
    purpose: v.optional(v.string()),
    departureDate: v.optional(v.string()),
    departureTime: v.optional(v.string()),
    arrivalDate: v.optional(v.string()),
    arrivalTime: v.optional(v.string()),
    kmDeparture: v.optional(v.number()),
    kmArrival: v.optional(v.number()),
    fuelCost: v.optional(v.number()),
    damages: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, ...fields } = args;
    await ctx.db.patch(id, fields);
  },
});

export const deleteUsage = mutation({
  args: { id: v.id("vehicleUsage") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.id);
  },
});
