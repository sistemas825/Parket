import { internalQuery } from "./_generated/server";

// Internal query that collects all relevant data as context for the AI
export const getSystemContext = internalQuery({
  args: {},
  handler: async (ctx) => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();

    // Products with stock
    const products = await ctx.db
      .query("products")
      .withIndex("by_active", (q) => q.eq("active", true))
      .collect();

    // All clients
    const clients = await ctx.db.query("clients").collect();

    // Recent orders (last 100)
    const orders = await ctx.db.query("orders").order("desc").take(100);

    // Enrich orders with client and items
    const ordersEnriched = await Promise.all(
      orders.map(async (order) => {
        const client = await ctx.db.get(order.clientId);
        const items = await ctx.db
          .query("orderItems")
          .withIndex("by_order", (q) => q.eq("orderId", order._id))
          .collect();
        const itemsEnriched = await Promise.all(
          items.map(async (item) => {
            const product = await ctx.db.get(item.productId);
            return {
              productName: product?.name ?? "—",
              productCode: product?.code ?? "—",
              unit: product?.unit ?? "un",
              m2PerBox: product?.m2PerBox,
              quantity: item.quantity,
              unitPrice: item.unitPrice,
            };
          })
        );
        return {
          orderNumber: order.orderNumber,
          status: order.status,
          freightType: order.freightType,
          freightValue: order.freightValue,
          clientName: client?.name ?? "—",
          clientCity: client?.city ?? "—",
          deliveryAddress: order.deliveryAddress,
          scheduledDate: order.scheduledDate,
          deliveredAt: order.deliveredAt,
          notes: order.notes,
          createdAt: new Date(order._creationTime).toISOString(),
          items: itemsEnriched,
        };
      })
    );

    // Recent stock movements (last 100)
    const movements = await ctx.db.query("stockMovements").order("desc").take(100);
    const movementsEnriched = await Promise.all(
      movements.map(async (m) => {
        const product = await ctx.db.get(m.productId);
        const client = m.clientId ? await ctx.db.get(m.clientId) : null;
        return {
          type: m.type,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          unit: product?.unit ?? "un",
          quantity: m.quantity,
          quantityBefore: m.quantityBefore,
          quantityAfter: m.quantityAfter,
          reason: m.reason,
          clientName: client?.name ?? null,
          createdAt: new Date(m._creationTime).toISOString(),
        };
      })
    );

    // Summary stats
    const todayOrders = ordersEnriched.filter((o) => o.createdAt >= todayStart);
    const monthOrders = ordersEnriched.filter((o) => o.createdAt >= monthStart);
    const pendingOrders = ordersEnriched.filter((o) =>
      ["confirmado", "em_separacao", "em_rota"].includes(o.status)
    );
    const lowStockProducts = products.filter(
      (p) => p.minStock != null && p.currentStock <= p.minStock
    );

    return {
      currentDate: now.toISOString(),
      products: products.map((p) => ({
        name: p.name,
        code: p.code,
        unit: p.unit,
        m2PerBox: p.m2PerBox,
        currentStock: p.currentStock,
        minStock: p.minStock,
        costPrice: p.costPrice,
      })),
      clients: clients.map((c) => ({
        name: c.name,
        city: c.city,
        state: c.state,
        phone: c.phone,
        freightType: c.freightType,
        freightValue: c.freightValue,
      })),
      recentOrders: ordersEnriched,
      recentMovements: movementsEnriched,
      summary: {
        totalProducts: products.length,
        totalClients: clients.length,
        ordersToday: todayOrders.length,
        ordersThisMonth: monthOrders.length,
        pendingOrdersCount: pendingOrders.length,
        pendingOrders: pendingOrders.map((o) => ({
          orderNumber: o.orderNumber,
          clientName: o.clientName,
          status: o.status,
          scheduledDate: o.scheduledDate,
        })),
        lowStockProducts: lowStockProducts.map((p) => ({
          name: p.name,
          code: p.code,
          currentStock: p.currentStock,
          minStock: p.minStock,
          unit: p.unit,
        })),
      },
    };
  },
});
