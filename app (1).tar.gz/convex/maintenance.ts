import { query, mutation } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import type { MutationCtx, QueryCtx } from "./_generated/server";

async function requireUser(ctx: MutationCtx | QueryCtx) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });
  return user;
}

// List maintenance records with optional filters
export const listMaintenance = query({
  args: {
    vehicleId: v.optional(v.id("vehicles")),
    status: v.optional(v.union(v.literal("pendente"), v.literal("em_andamento"), v.literal("concluida"))),
  },
  handler: async (ctx, args) => {
    let records = args.vehicleId
      ? await ctx.db
          .query("vehicleMaintenance")
          .withIndex("by_vehicle", (q) => q.eq("vehicleId", args.vehicleId!))
          .order("desc")
          .collect()
      : await ctx.db.query("vehicleMaintenance").order("desc").collect();

    if (args.status) records = records.filter((r) => r.status === args.status);

    // Enrich with vehicle info
    const enriched = await Promise.all(
      records.map(async (r) => {
        const vehicle = await ctx.db.get(r.vehicleId);
        const usage = r.usageId ? await ctx.db.get(r.usageId) : null;
        const budgetPhotoUrl = r.budgetPhotoId
          ? await ctx.storage.getUrl(r.budgetPhotoId as Parameters<typeof ctx.storage.getUrl>[0])
          : null;
        return { ...r, vehicle, linkedUsage: usage, budgetPhotoUrl };
      })
    );
    return enriched;
  },
});

export const getMaintenance = query({
  args: { id: v.id("vehicleMaintenance") },
  handler: async (ctx, args) => {
    const record = await ctx.db.get(args.id);
    if (!record) return null;
    const vehicle = await ctx.db.get(record.vehicleId);
    const usage = record.usageId ? await ctx.db.get(record.usageId) : null;
    return { ...record, vehicle, linkedUsage: usage };
  },
});

// List usage records that have damage (to link to maintenance)
export const listUsageWithDamages = query({
  args: { vehicleId: v.optional(v.id("vehicles")) },
  handler: async (ctx, args) => {
    let records = args.vehicleId
      ? await ctx.db
          .query("vehicleUsage")
          .withIndex("by_vehicle", (q) => q.eq("vehicleId", args.vehicleId!))
          .collect()
      : await ctx.db.query("vehicleUsage").collect();

    // Only records with damages
    records = records.filter((r) => r.damages && r.damages.trim().length > 0);

    const enriched = await Promise.all(
      records.map(async (r) => {
        const vehicle = await ctx.db.get(r.vehicleId);
        return { ...r, vehicle };
      })
    );
    return enriched.sort((a, b) => b.departureDate.localeCompare(a.departureDate));
  },
});

export const createMaintenance = mutation({
  args: {
    vehicleId: v.id("vehicles"),
    type: v.union(
      v.literal("preventiva"),
      v.literal("corretiva"),
      v.literal("revisao"),
      v.literal("pneu"),
      v.literal("outros")
    ),
    description: v.string(),
    workshop: v.optional(v.string()),
    cost: v.optional(v.number()),
    date: v.string(),
    status: v.union(v.literal("pendente"), v.literal("em_andamento"), v.literal("concluida")),
    usageId: v.optional(v.id("vehicleUsage")),
    notes: v.optional(v.string()),
    photoIds: v.optional(v.array(v.string())),
    budgetPhotoId: v.optional(v.string()),
    budgetValue: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const user = await requireUser(ctx);
    const id = await ctx.db.insert("vehicleMaintenance", { ...args, createdBy: user._id });

    // If status = em_andamento or pendente, set vehicle to manutencao
    if (args.status !== "concluida") {
      await ctx.db.patch(args.vehicleId, { status: "manutencao" });
    }
    return id;
  },
});

export const updateMaintenance = mutation({
  args: {
    id: v.id("vehicleMaintenance"),
    type: v.optional(v.union(
      v.literal("preventiva"),
      v.literal("corretiva"),
      v.literal("revisao"),
      v.literal("pneu"),
      v.literal("outros")
    )),
    description: v.optional(v.string()),
    workshop: v.optional(v.string()),
    cost: v.optional(v.number()),
    date: v.optional(v.string()),
    resolvedAt: v.optional(v.string()),
    status: v.optional(v.union(v.literal("pendente"), v.literal("em_andamento"), v.literal("concluida"))),
    usageId: v.optional(v.id("vehicleUsage")),
    notes: v.optional(v.string()),
    photoIds: v.optional(v.array(v.string())),
    budgetPhotoId: v.optional(v.string()),
    budgetValue: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const { id, ...fields } = args;
    const record = await ctx.db.get(id);
    if (!record) throw new ConvexError({ message: "Registro não encontrado", code: "NOT_FOUND" });

    const updates: Partial<typeof fields> = {};
    for (const [k, v] of Object.entries(fields)) {
      if (v !== undefined) (updates as Record<string, unknown>)[k] = v;
    }

    // If concluding, set resolvedAt and restore vehicle status
    if (fields.status === "concluida") {
      if (!fields.resolvedAt) updates.resolvedAt = new Date().toISOString().split("T")[0];
      // Check if vehicle has other open maintenances
      const others = await ctx.db
        .query("vehicleMaintenance")
        .withIndex("by_vehicle", (q) => q.eq("vehicleId", record.vehicleId))
        .collect();
      const otherOpen = others.filter(
        (r) => r._id !== id && (r.status === "pendente" || r.status === "em_andamento")
      );
      if (otherOpen.length === 0) {
        await ctx.db.patch(record.vehicleId, { status: "disponivel" });
      }
    }

    await ctx.db.patch(id, updates);
  },
});

export const deleteMaintenance = mutation({
  args: { id: v.id("vehicleMaintenance") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    await ctx.db.delete(args.id);
  },
});

// Quick-conclude: mark as concluida and restore vehicle status
export const concludeMaintenance = mutation({
  args: { id: v.id("vehicleMaintenance") },
  handler: async (ctx, args) => {
    await requireUser(ctx);
    const record = await ctx.db.get(args.id);
    if (!record) throw new ConvexError({ message: "Registro não encontrado", code: "NOT_FOUND" });

    await ctx.db.patch(args.id, {
      status: "concluida",
      resolvedAt: new Date().toISOString().split("T")[0],
    });

    // Restore vehicle to disponivel if no other open maintenances
    const others = await ctx.db
      .query("vehicleMaintenance")
      .withIndex("by_vehicle", (q) => q.eq("vehicleId", record.vehicleId))
      .collect();
    const otherOpen = others.filter(
      (r) => r._id !== args.id && (r.status === "pendente" || r.status === "em_andamento")
    );
    if (otherOpen.length === 0) {
      await ctx.db.patch(record.vehicleId, { status: "disponivel" });
    }
  },
});

// Generate upload URL for maintenance photos
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireUser(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});
