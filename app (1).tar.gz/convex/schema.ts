import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  users: defineTable({
    tokenIdentifier: v.string(),
    name: v.optional(v.string()),
    email: v.optional(v.string()),
  }).index("by_token", ["tokenIdentifier"]),

  // Categorias de produtos
  categories: defineTable({
    name: v.string(),
    description: v.optional(v.string()),
    createdBy: v.id("users"),
  }),

  // Cadastro de produtos
  products: defineTable({
    name: v.string(),
    code: v.string(), // código interno
    description: v.optional(v.string()),
    categoryId: v.optional(v.id("categories")),
    // Unidade de medida: m2, cx, ml (metros lineares)
    unit: v.union(v.literal("m2"), v.literal("cx"), v.literal("ml"), v.literal("un")),
    // Para caixas: quantos m2 por caixa
    m2PerBox: v.optional(v.number()),
    // Preço de custo unitário
    costPrice: v.optional(v.number()),
    // Estoque atual
    currentStock: v.number(),
    // Estoque mínimo para alerta
    minStock: v.optional(v.number()),
    imageStorageId: v.optional(v.string()),
    createdBy: v.id("users"),
    active: v.boolean(),
  })
    .index("by_code", ["code"])
    .index("by_category", ["categoryId"])
    .index("by_active", ["active"]),

  // Cadastro de clientes
  clients: defineTable({
    name: v.string(),
    document: v.optional(v.string()), // CPF ou CNPJ
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    // Endereço
    address: v.optional(v.string()),
    addressNumber: v.optional(v.string()),
    complement: v.optional(v.string()),
    neighborhood: v.optional(v.string()),
    city: v.optional(v.string()),
    state: v.optional(v.string()),
    zipCode: v.optional(v.string()),
    // Frete
    freightType: v.union(v.literal("interno"), v.literal("terceiro"), v.literal("retirada")),
    freightValue: v.optional(v.number()),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
    active: v.boolean(),
  })
    .index("by_name", ["name"])
    .index("by_active", ["active"]),

  // Pedidos
  orders: defineTable({
    orderNumber: v.string(),
    clientId: v.id("clients"),
    status: v.union(
      v.literal("rascunho"),
      v.literal("confirmado"),
      v.literal("em_separacao"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado")
    ),
    freightType: v.union(v.literal("interno"), v.literal("terceiro"), v.literal("retirada")),
    freightValue: v.optional(v.number()),
    notes: v.optional(v.string()),
    deliveryAddress: v.optional(v.string()),
    scheduledDate: v.optional(v.string()),
    deliveredAt: v.optional(v.string()),
    createdBy: v.id("users"),
    updatedBy: v.optional(v.id("users")),
  })
    .index("by_status", ["status"])
    .index("by_client", ["clientId"])
    .index("by_order_number", ["orderNumber"]),

  // Itens do pedido
  orderItems: defineTable({
    orderId: v.id("orders"),
    productId: v.id("products"),
    quantity: v.number(), // em unidades da medida do produto
    unitPrice: v.optional(v.number()),
    notes: v.optional(v.string()),
  }).index("by_order", ["orderId"]),

  // Movimentações de estoque
  stockMovements: defineTable({
    productId: v.id("products"),
    type: v.union(
      v.literal("entrada"),
      v.literal("saida"),
      v.literal("ajuste"),
      v.literal("inventario"),
      v.literal("transferencia")
    ),
    quantity: v.number(), // positivo = entrada, negativo = saída
    quantityBefore: v.number(),
    quantityAfter: v.number(),
    orderId: v.optional(v.id("orders")),
    clientId: v.optional(v.id("clients")),
    reason: v.optional(v.string()),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
  })
    .index("by_product", ["productId"])
    .index("by_order", ["orderId"])
    .index("by_type", ["type"]),

  // Assinaturas digitais de entrega
  orderSignatures: defineTable({
    orderId: v.id("orders"),
    signerName: v.string(),         // nome de quem assinou
    signatureData: v.string(),      // base64 da assinatura (PNG)
    signedAt: v.string(),           // ISO timestamp
    createdBy: v.optional(v.id("users")), // opcional — cliente público não tem usuário
  }).index("by_order", ["orderId"]),

  // Fotos dos pedidos (separação, entrega)
  orderPhotos: defineTable({
    orderId: v.id("orders"),
    storageId: v.string(),
    type: v.union(v.literal("separacao"), v.literal("entrega"), v.literal("outros")),
    caption: v.optional(v.string()),
    createdBy: v.id("users"),
  }).index("by_order", ["orderId"]),

  // Fotos de transporte de ferramentas
  toolTransportPhotos: defineTable({
    transportId: v.id("toolTransports"),
    storageId: v.string(),
    type: v.union(v.literal("retirada"), v.literal("entrega"), v.literal("outros")),
    caption: v.optional(v.string()),
    createdBy: v.id("users"),
  }).index("by_transport", ["transportId"]),

  // Transporte de ferramentas (separado de pedidos de produtos)
  toolTransports: defineTable({
    transportNumber: v.string(),
    clientId: v.id("clients"),
    // "retirar" = retirar ferramentas no cliente
    // "entregar" = entregar ferramentas para o cliente
    direction: v.union(v.literal("retirar"), v.literal("entregar")),
    // Cliente de destino - usado quando direction === "retirar"
    // indica para qual cliente as ferramentas serão levadas após a retirada
    destinationClientId: v.optional(v.id("clients")),
    freightType: v.union(v.literal("interno"), v.literal("terceiro")),
    freightValue: v.optional(v.number()),
    status: v.union(
      v.literal("pendente"),
      v.literal("em_rota"),
      v.literal("entregue"),
      v.literal("cancelado")
    ),
    tools: v.array(
      v.object({
        name: v.string(),
        quantity: v.number(),
        notes: v.optional(v.string()),
      })
    ),
    pickupAddress: v.optional(v.string()),
    deliveryAddress: v.optional(v.string()),
    scheduledDate: v.optional(v.string()),
    deliveredAt: v.optional(v.string()),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
    updatedBy: v.optional(v.id("users")),
  })
    .index("by_status", ["status"])
    .index("by_client", ["clientId"])
    .index("by_transport_number", ["transportNumber"]),

  // Notificações in-app
  notifications: defineTable({
    userId: v.id("users"),
    type: v.union(
      v.literal("order_status"),
      v.literal("transport_status"),
    ),
    title: v.string(),
    message: v.string(),
    // id do pedido ou transporte relacionado
    relatedId: v.string(),
    relatedNumber: v.string(),
    // status novo
    newStatus: v.string(),
    read: v.boolean(),
    // dados para envio WhatsApp
    clientPhone: v.optional(v.string()),
    whatsappMessage: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_user_read", ["userId", "read"]),

  // Cliente da Semana
  weeklyClients: defineTable({
    weekLabel: v.string(), // ex: "2024-W20"
    clientCode: v.string(),
    clientName: v.string(),
    os: v.string(),
    material: v.optional(v.string()), // preenchido manualmente
    createdBy: v.id("users"),
  })
    .index("by_week", ["weekLabel"])
    .index("by_os", ["os"]),

  // Frota — veículos
  vehicles: defineTable({
    plate: v.string(),         // placa
    model: v.string(),         // modelo
    brand: v.string(),         // marca
    year: v.optional(v.number()),
    type: v.union(v.literal("carro"), v.literal("caminhao"), v.literal("van"), v.literal("moto")),
    color: v.optional(v.string()),
    status: v.union(v.literal("disponivel"), v.literal("em_uso"), v.literal("manutencao")),
    notes: v.optional(v.string()),
    currentKm: v.optional(v.number()),
    createdBy: v.id("users"),
    active: v.boolean(),
  })
    .index("by_plate", ["plate"])
    .index("by_status", ["status"])
    .index("by_active", ["active"]),

  // Frota — registros de uso
  vehicleUsage: defineTable({
    vehicleId: v.id("vehicles"),
    driverName: v.string(),
    destination: v.optional(v.string()),
    purpose: v.optional(v.string()),
    departureDate: v.string(),     // ISO date string
    departureTime: v.string(),     // HH:mm
    arrivalDate: v.optional(v.string()),
    arrivalTime: v.optional(v.string()),
    kmDeparture: v.number(),
    kmArrival: v.optional(v.number()),
    kmDriven: v.optional(v.number()),
    fuelCost: v.optional(v.number()),
    damages: v.optional(v.string()),  // descrição de avarias
    damagePhotoIds: v.optional(v.array(v.string())),
    notes: v.optional(v.string()),
    status: v.union(v.literal("aberto"), v.literal("concluido")),
    createdBy: v.id("users"),
  })
    .index("by_vehicle", ["vehicleId"])
    .index("by_driver", ["driverName"])
    .index("by_status", ["status"])
    .index("by_departure", ["departureDate"]),

  // Frota — manutenções
  vehicleMaintenance: defineTable({
    vehicleId: v.id("vehicles"),
    type: v.union(
      v.literal("preventiva"),
      v.literal("corretiva"),
      v.literal("revisao"),
      v.literal("pneu"),
      v.literal("outros")
    ),
    description: v.string(),
    workshop: v.optional(v.string()),    // oficina
    cost: v.optional(v.number()),
    date: v.string(),                    // ISO date
    resolvedAt: v.optional(v.string()), // data de conclusão
    status: v.union(v.literal("pendente"), v.literal("em_andamento"), v.literal("concluida")),
    usageId: v.optional(v.id("vehicleUsage")), // avaria vinculada
    notes: v.optional(v.string()),
    photoIds: v.optional(v.array(v.string())),
    budgetPhotoId: v.optional(v.string()),   // foto do orçamento
    budgetValue: v.optional(v.number()),      // valor do orçamento
    createdBy: v.id("users"),
  })
    .index("by_vehicle", ["vehicleId"])
    .index("by_status", ["status"])
    .index("by_date", ["date"]),

  // Inventários
  inventories: defineTable({
    name: v.string(),
    status: v.union(v.literal("aberto"), v.literal("em_andamento"), v.literal("finalizado")),
    notes: v.optional(v.string()),
    createdBy: v.id("users"),
    finishedAt: v.optional(v.string()),
  }),

  // Itens do inventário
  inventoryItems: defineTable({
    inventoryId: v.id("inventories"),
    productId: v.id("products"),
    expectedQuantity: v.number(),
    countedQuantity: v.optional(v.number()),
    difference: v.optional(v.number()),
    notes: v.optional(v.string()),
    countedBy: v.optional(v.id("users")),
  })
    .index("by_inventory", ["inventoryId"])
    .index("by_product", ["productId"]),
});
