import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";

// ---- INVENTORY ----

export const listInventories = query({
  args: {},
  handler: async (ctx) => {
    const inventories = await ctx.db.query("inventories").order("desc").collect();
    return await Promise.all(
      inventories.map(async (inv) => {
        const items = await ctx.db
          .query("inventoryItems")
          .withIndex("by_inventory", (q) => q.eq("inventoryId", inv._id))
          .collect();
        const counted = items.filter((i) => i.countedQuantity != null).length;
        const user = await ctx.db.get(inv.createdBy);
        return { ...inv, totalItems: items.length, countedItems: counted, createdByName: user?.name ?? "—" };
      })
    );
  },
});

export const getInventory = query({
  args: { id: v.id("inventories") },
  handler: async (ctx, args) => {
    const inv = await ctx.db.get(args.id);
    if (!inv) return null;
    const items = await ctx.db
      .query("inventoryItems")
      .withIndex("by_inventory", (q) => q.eq("inventoryId", args.id))
      .collect();
    const itemsWithProduct = await Promise.all(
      items.map(async (item) => {
        const product = await ctx.db.get(item.productId);
        const counter = item.countedBy ? await ctx.db.get(item.countedBy) : null;
        return {
          ...item,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          m2PerBox: product?.m2PerBox,
          counterName: counter?.name ?? null,
        };
      })
    );
    return { ...inv, items: itemsWithProduct };
  },
});

export const createInventory = mutation({
  args: {
    name: v.string(),
    notes: v.optional(v.string()),
    includeAllProducts: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const invId = await ctx.db.insert("inventories", {
      name: args.name,
      status: "aberto",
      notes: args.notes,
      createdBy: user._id,
    });

    if (args.includeAllProducts) {
      const products = await ctx.db.query("products").withIndex("by_active", (q) => q.eq("active", true)).collect();
      for (const product of products) {
        await ctx.db.insert("inventoryItems", {
          inventoryId: invId,
          productId: product._id,
          expectedQuantity: product.currentStock,
        });
      }
    }

    return invId;
  },
});

export const updateInventoryStatus = mutation({
  args: {
    id: v.id("inventories"),
    status: v.union(v.literal("aberto"), v.literal("em_andamento"), v.literal("finalizado")),
  },
  handler: async (ctx, args) => {
    const patch: Record<string, unknown> = { status: args.status };
    if (args.status === "finalizado") patch.finishedAt = new Date().toISOString();
    await ctx.db.patch(args.id, patch);
  },
});

export const countInventoryItem = mutation({
  args: {
    id: v.id("inventoryItems"),
    countedQuantity: v.number(),
    notes: v.optional(v.string()),
    applyToStock: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const item = await ctx.db.get(args.id);
    if (!item) throw new ConvexError({ message: "Item não encontrado", code: "NOT_FOUND" });

    const difference = args.countedQuantity - item.expectedQuantity;

    await ctx.db.patch(args.id, {
      countedQuantity: args.countedQuantity,
      difference,
      notes: args.notes,
      countedBy: user._id,
    });

    if (args.applyToStock) {
      const product = await ctx.db.get(item.productId);
      if (product) {
        const quantityBefore = product.currentStock;
        const quantityAfter = args.countedQuantity;
        await ctx.db.patch(item.productId, { currentStock: quantityAfter });
        await ctx.db.insert("stockMovements", {
          productId: item.productId,
          type: "inventario",
          quantity: quantityAfter - quantityBefore,
          quantityBefore,
          quantityAfter,
          reason: "Ajuste de inventário",
          createdBy: user._id,
        });
      }
    }
  },
});

export const finalizeInventory = mutation({
  args: { id: v.id("inventories"), applyAll: v.boolean() },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    if (args.applyAll) {
      const items = await ctx.db.query("inventoryItems").withIndex("by_inventory", (q) => q.eq("inventoryId", args.id)).collect();
      for (const item of items) {
        if (item.countedQuantity == null) continue;
        const product = await ctx.db.get(item.productId);
        if (!product) continue;
        const quantityBefore = product.currentStock;
        const quantityAfter = item.countedQuantity;
        if (quantityBefore === quantityAfter) continue;
        await ctx.db.patch(item.productId, { currentStock: quantityAfter });
        await ctx.db.insert("stockMovements", {
          productId: item.productId,
          type: "inventario",
          quantity: quantityAfter - quantityBefore,
          quantityBefore,
          quantityAfter,
          reason: "Finalização de inventário",
          createdBy: user._id,
        });
      }
    }
    await ctx.db.patch(args.id, { status: "finalizado", finishedAt: new Date().toISOString() });
  },
});

export const deleteInventory = mutation({
  args: { id: v.id("inventories") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });

    // Delete all inventory items first
    const items = await ctx.db
      .query("inventoryItems")
      .withIndex("by_inventory", (q) => q.eq("inventoryId", args.id))
      .collect();
    await Promise.all(items.map((item) => ctx.db.delete(item._id)));

    // Delete the inventory itself
    await ctx.db.delete(args.id);
  },
});
