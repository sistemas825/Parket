import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";

export const getOrderSignature = query({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("orderSignatures")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .first();
  },
});

// Used by authenticated staff
export const saveOrderSignature = mutation({
  args: {
    orderId: v.id("orders"),
    signerName: v.string(),
    signatureData: v.string(),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const existing = await ctx.db
      .query("orderSignatures")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .first();
    if (existing) await ctx.db.delete(existing._id);

    return await ctx.db.insert("orderSignatures", {
      orderId: args.orderId,
      signerName: args.signerName.trim(),
      signatureData: args.signatureData,
      signedAt: new Date().toISOString(),
      createdBy: user._id,
    });
  },
});

// Used by unauthenticated client on public order page
export const saveOrderSignaturePublic = mutation({
  args: {
    orderId: v.id("orders"),
    signerName: v.string(),
    signatureData: v.string(),
  },
  handler: async (ctx, args) => {
    // Verify the order exists
    const order = await ctx.db.get(args.orderId);
    if (!order) throw new ConvexError({ message: "Pedido não encontrado", code: "NOT_FOUND" });

    // Only allow signing if order is not cancelled
    if (order.status === "cancelado") {
      throw new ConvexError({ message: "Pedido cancelado não pode ser assinado", code: "BAD_REQUEST" });
    }

    // Remove existing signature if any
    const existing = await ctx.db
      .query("orderSignatures")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .first();
    if (existing) await ctx.db.delete(existing._id);

    return await ctx.db.insert("orderSignatures", {
      orderId: args.orderId,
      signerName: args.signerName.trim(),
      signatureData: args.signatureData,
      signedAt: new Date().toISOString(),
    });
  },
});

export const deleteOrderSignature = mutation({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const sig = await ctx.db
      .query("orderSignatures")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .first();
    if (sig) await ctx.db.delete(sig._id);
  },
});
