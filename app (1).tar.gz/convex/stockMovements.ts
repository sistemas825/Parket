import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import { paginationOptsValidator } from "convex/server";

export const listMovements = query({
  args: {
    paginationOpts: paginationOptsValidator,
    productId: v.optional(v.id("products")),
    type: v.optional(v.union(
      v.literal("entrada"),
      v.literal("saida"),
      v.literal("ajuste"),
      v.literal("inventario"),
      v.literal("transferencia")
    )),
  },
  handler: async (ctx, args) => {
    const base = args.productId
      ? ctx.db.query("stockMovements").withIndex("by_product", (q) => q.eq("productId", args.productId!))
      : args.type
      ? ctx.db.query("stockMovements").withIndex("by_type", (q) => q.eq("type", args.type!))
      : ctx.db.query("stockMovements");

    const result = await base.order("desc").paginate(args.paginationOpts);

    const page = await Promise.all(
      result.page.map(async (m) => {
        const product = await ctx.db.get(m.productId);
        const user = await ctx.db.get(m.createdBy);
        const client = m.clientId ? await ctx.db.get(m.clientId) : null;
        return {
          ...m,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          userName: user?.name ?? "—",
          clientName: client?.name ?? null,
        };
      })
    );
    return { ...result, page };
  },
});

export const listMovementsByDate = query({
  args: {
    dateStart: v.number(),
    dateEnd: v.number(),
    type: v.optional(v.union(
      v.literal("entrada"),
      v.literal("saida"),
      v.literal("ajuste"),
      v.literal("inventario"),
      v.literal("transferencia")
    )),
  },
  handler: async (ctx, args) => {
    const movements = await ctx.db
      .query("stockMovements")
      .order("desc")
      .collect();

    const filtered = movements.filter(
      (m) =>
        m._creationTime >= args.dateStart &&
        m._creationTime <= args.dateEnd &&
        (args.type ? m.type === args.type : true)
    );

    return await Promise.all(
      filtered.map(async (m) => {
        const product = await ctx.db.get(m.productId);
        const user = await ctx.db.get(m.createdBy);
        const client = m.clientId ? await ctx.db.get(m.clientId) : null;
        return {
          ...m,
          productName: product?.name ?? "—",
          productCode: product?.code ?? "—",
          productUnit: product?.unit ?? "un",
          userName: user?.name ?? "—",
          clientName: client?.name ?? null,
        };
      })
    );
  },
});

export const createMovement = mutation({
  args: {
    productId: v.id("products"),
    type: v.union(
      v.literal("entrada"),
      v.literal("saida"),
      v.literal("ajuste"),
      v.literal("inventario"),
      v.literal("transferencia")
    ),
    quantity: v.number(),
    reason: v.optional(v.string()),
    notes: v.optional(v.string()),
    orderId: v.optional(v.id("orders")),
    clientId: v.optional(v.id("clients")),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const product = await ctx.db.get(args.productId);
    if (!product) throw new ConvexError({ message: "Produto não encontrado", code: "NOT_FOUND" });

    const quantityBefore = product.currentStock;
    let delta: number;

    if (args.type === "saida") {
      delta = -Math.abs(args.quantity);
    } else if (args.type === "entrada" || args.type === "transferencia") {
      delta = Math.abs(args.quantity);
    } else {
      // ajuste / inventario: quantity = new absolute stock value
      delta = args.quantity - quantityBefore;
    }

    const quantityAfter = quantityBefore + delta;
    if (quantityAfter < 0) throw new ConvexError({ message: "Estoque insuficiente para esta saída", code: "BAD_REQUEST" });

    await ctx.db.patch(args.productId, { currentStock: quantityAfter });

    return await ctx.db.insert("stockMovements", {
      productId: args.productId,
      type: args.type,
      quantity: delta,
      quantityBefore,
      quantityAfter,
      orderId: args.orderId,
      clientId: args.clientId,
      reason: args.reason,
      notes: args.notes,
      createdBy: user._id,
    });
  },
});
