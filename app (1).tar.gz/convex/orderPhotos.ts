import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const addOrderPhoto = mutation({
  args: {
    orderId: v.id("orders"),
    storageId: v.string(),
    type: v.union(v.literal("separacao"), v.literal("entrega"), v.literal("outros")),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    return await ctx.db.insert("orderPhotos", {
      orderId: args.orderId,
      storageId: args.storageId,
      type: args.type,
      caption: args.caption,
      createdBy: user._id,
    });
  },
});

export const addOrderPhotoPublic = mutation({
  args: {
    orderId: v.id("orders"),
    storageId: v.string(),
    type: v.union(v.literal("separacao"), v.literal("entrega"), v.literal("outros")),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Public mutation — no auth required, used for delivery photo upload by client
    const order = await ctx.db.get(args.orderId);
    if (!order) throw new ConvexError({ message: "Pedido não encontrado", code: "NOT_FOUND" });
    if (order.status !== "entregue") throw new ConvexError({ message: "Fotos de entrega só podem ser adicionadas após a entrega", code: "BAD_REQUEST" });

    // Use a system user sentinel — find first user or store without createdBy
    const users = await ctx.db.query("users").first();
    if (!users) throw new ConvexError({ message: "Sem usuário no sistema", code: "NOT_FOUND" });

    return await ctx.db.insert("orderPhotos", {
      orderId: args.orderId,
      storageId: args.storageId,
      type: "entrega",
      caption: args.caption,
      createdBy: users._id,
    });
  },
});

export const generateUploadUrlPublic = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
export const deleteOrderPhoto = mutation({
  args: { id: v.id("orderPhotos") },
  handler: async (ctx, args) => {
    const photo = await ctx.db.get(args.id);
    if (!photo) throw new ConvexError({ message: "Foto não encontrada", code: "NOT_FOUND" });
    await ctx.storage.delete(photo.storageId as `${string}`);
    await ctx.db.delete(args.id);
  },
});

export const getOrderPhotos = query({
  args: { orderId: v.id("orders") },
  handler: async (ctx, args) => {
    const photos = await ctx.db
      .query("orderPhotos")
      .withIndex("by_order", (q) => q.eq("orderId", args.orderId))
      .order("desc")
      .collect();

    return await Promise.all(
      photos.map(async (photo) => {
        const url = await ctx.storage.getUrl(photo.storageId);
        const user = await ctx.db.get(photo.createdBy);
        return { ...photo, url, userName: user?.name ?? "—" };
      })
    );
  },
});
