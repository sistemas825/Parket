import { query, mutation } from "./_generated/server";
import { v, ConvexError } from "convex/values";

// Public queries — no auth required, used by the driver portal

export const listVehiclesPublic = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("vehicles")
      .withIndex("by_active", (q) => q.eq("active", true))
      .collect();
  },
});

export const getOpenUsageForVehicle = query({
  args: { vehicleId: v.id("vehicles") },
  handler: async (ctx, args) => {
    const usage = await ctx.db
      .query("vehicleUsage")
      .withIndex("by_vehicle", (q) => q.eq("vehicleId", args.vehicleId))
      .order("desc")
      .filter((q) => q.eq(q.field("status"), "aberto"))
      .first();
    if (!usage) return null;
    const vehicle = await ctx.db.get(usage.vehicleId);
    return { ...usage, vehicle };
  },
});

export const generateUploadUrlPublic = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

// Public mutation: register departure — no auth required
export const createUsagePublic = mutation({
  args: {
    vehicleId: v.id("vehicles"),
    driverName: v.string(),
    destination: v.optional(v.string()),
    purpose: v.optional(v.string()),
    departureDate: v.string(),
    departureTime: v.string(),
    kmDeparture: v.number(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const vehicle = await ctx.db.get(args.vehicleId);
    if (!vehicle) throw new ConvexError({ message: "Veículo não encontrado", code: "NOT_FOUND" });
    if (vehicle.status === "em_uso") throw new ConvexError({ message: "Veículo já está em uso", code: "CONFLICT" });

    const systemUser = await ctx.db.query("users").first();
    if (!systemUser) throw new ConvexError({ message: "Sistema não configurado", code: "NOT_FOUND" });

    await ctx.db.patch(args.vehicleId, { status: "em_uso" });
    return await ctx.db.insert("vehicleUsage", {
      ...args,
      status: "aberto",
      createdBy: systemUser._id,
    });
  },
});

// Public mutation: register arrival — no auth required
export const closeUsagePublic = mutation({
  args: {
    id: v.id("vehicleUsage"),
    arrivalDate: v.string(),
    arrivalTime: v.string(),
    kmArrival: v.number(),
    fuelCost: v.optional(v.number()),
    damages: v.optional(v.string()),
    damagePhotoIds: v.optional(v.array(v.string())),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { id, kmArrival, ...rest } = args;
    const usage = await ctx.db.get(id);
    if (!usage) throw new ConvexError({ message: "Registro não encontrado", code: "NOT_FOUND" });
    const kmDriven = kmArrival - usage.kmDeparture;
    await ctx.db.patch(id, { ...rest, kmArrival, kmDriven, status: "concluido" });
    await ctx.db.patch(usage.vehicleId, { currentKm: kmArrival, status: "disponivel" });
  },
});
