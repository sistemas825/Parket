/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as clients from "../clients.js";
import type * as dada from "../dada.js";
import type * as dadaQueries from "../dadaQueries.js";
import type * as fleet from "../fleet.js";
import type * as fleetPublic from "../fleetPublic.js";
import type * as inventory from "../inventory.js";
import type * as maintenance from "../maintenance.js";
import type * as notifications from "../notifications.js";
import type * as orderPhotos from "../orderPhotos.js";
import type * as orderSignatures from "../orderSignatures.js";
import type * as orders from "../orders.js";
import type * as products from "../products.js";
import type * as reports from "../reports.js";
import type * as stockMovements from "../stockMovements.js";
import type * as toolTransportPhotos from "../toolTransportPhotos.js";
import type * as toolTransports from "../toolTransports.js";
import type * as users from "../users.js";
import type * as weeklyClients from "../weeklyClients.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  clients: typeof clients;
  dada: typeof dada;
  dadaQueries: typeof dadaQueries;
  fleet: typeof fleet;
  fleetPublic: typeof fleetPublic;
  inventory: typeof inventory;
  maintenance: typeof maintenance;
  notifications: typeof notifications;
  orderPhotos: typeof orderPhotos;
  orderSignatures: typeof orderSignatures;
  orders: typeof orders;
  products: typeof products;
  reports: typeof reports;
  stockMovements: typeof stockMovements;
  toolTransportPhotos: typeof toolTransportPhotos;
  toolTransports: typeof toolTransports;
  users: typeof users;
  weeklyClients: typeof weeklyClients;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
