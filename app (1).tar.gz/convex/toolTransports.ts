import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";
import { paginationOptsValidator } from "convex/server";

const freightTypeValidator = v.union(v.literal("interno"), v.literal("terceiro"));
const statusValidator = v.union(
  v.literal("pendente"),
  v.literal("em_rota"),
  v.literal("entregue"),
  v.literal("cancelado"),
);

export const getNextTransportNumber = query({
  args: {},
  handler: async (ctx) => {
    const last = await ctx.db.query("toolTransports").order("desc").first();
    if (!last) return "TRF-0001";
    const match = last.transportNumber.match(/\d+$/);
    const next = match ? parseInt(match[0]) + 1 : 1;
    return `TRF-${String(next).padStart(4, "0")}`;
  },
});

export const listTransports = query({
  args: {
    paginationOpts: paginationOptsValidator,
    status: v.optional(statusValidator),
  },
  handler: async (ctx, args) => {
    const base = args.status
      ? ctx.db
          .query("toolTransports")
          .withIndex("by_status", (q) => q.eq("status", args.status!))
      : ctx.db.query("toolTransports");

    const result = await base.order("desc").paginate(args.paginationOpts);

    const page = await Promise.all(
      result.page.map(async (t) => {
        const client = await ctx.db.get(t.clientId);
        const destinationClient = t.destinationClientId
          ? await ctx.db.get(t.destinationClientId)
          : null;
        return {
          ...t,
          clientName: client?.name ?? "—",
          clientPhone: client?.phone,
          clientCity: client?.city,
          clientDocument: client?.document,
          destinationClientName: destinationClient?.name,
          destinationClientCity: destinationClient?.city,
        };
      }),
    );
    return { ...result, page };
  },
});

export const getTransport = query({
  args: { id: v.id("toolTransports") },
  handler: async (ctx, args) => {
    const t = await ctx.db.get(args.id);
    if (!t) return null;
    const client = await ctx.db.get(t.clientId);
    return { ...t, client };
  },
});

export const createTransport = mutation({
  args: {
    transportNumber: v.string(),
    clientId: v.id("clients"),
    direction: v.union(v.literal("retirar"), v.literal("entregar")),
    destinationClientId: v.optional(v.id("clients")),
    freightType: freightTypeValidator,
    freightValue: v.optional(v.number()),
    pickupAddress: v.optional(v.string()),
    deliveryAddress: v.optional(v.string()),
    scheduledDate: v.optional(v.string()),
    notes: v.optional(v.string()),
    tools: v.array(
      v.object({
        name: v.string(),
        quantity: v.number(),
        notes: v.optional(v.string()),
      }),
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity)
      throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user)
      throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    return await ctx.db.insert("toolTransports", {
      ...args,
      status: "pendente",
      createdBy: user._id,
    });
  },
});

export const updateTransportStatus = mutation({
  args: {
    id: v.id("toolTransports"),
    status: statusValidator,
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity)
      throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user)
      throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const patch: Record<string, unknown> = { status: args.status, updatedBy: user._id };
    if (args.status === "entregue") patch.deliveredAt = new Date().toISOString();

    await ctx.db.patch(args.id, patch);
  },
});

export const deleteTransport = mutation({
  args: { id: v.id("toolTransports") },
  handler: async (ctx, args) => {
    await ctx.db.delete(args.id);
  },
});
