import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";

// List rows for a given week
export const listByWeek = query({
  args: { weekLabel: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("weeklyClients")
      .withIndex("by_week", (q) => q.eq("weekLabel", args.weekLabel))
      .collect();
  },
});

// List distinct week labels (newest first)
export const listWeeks = query({
  args: {},
  handler: async (ctx) => {
    const all = await ctx.db.query("weeklyClients").collect();
    const weeks = [...new Set(all.map((r) => r.weekLabel))].sort().reverse();
    return weeks;
  },
});

// Bulk import rows from Excel (replaces existing rows for the week)
export const bulkImport = mutation({
  args: {
    weekLabel: v.string(),
    rows: v.array(
      v.object({
        clientCode: v.string(),
        clientName: v.string(),
        os: v.string(),
      })
    ),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    // Remove existing rows for this week
    const existing = await ctx.db
      .query("weeklyClients")
      .withIndex("by_week", (q) => q.eq("weekLabel", args.weekLabel))
      .collect();
    for (const row of existing) {
      await ctx.db.delete(row._id);
    }

    for (const row of args.rows) {
      await ctx.db.insert("weeklyClients", {
        weekLabel: args.weekLabel,
        clientCode: row.clientCode,
        clientName: row.clientName,
        os: row.os,
        material: undefined,
        createdBy: user._id,
      });
    }

    return args.rows.length;
  },
});

// Update the material text for a single row
export const updateMaterial = mutation({
  args: {
    id: v.id("weeklyClients"),
    material: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    await ctx.db.patch(args.id, { material: args.material });
  },
});

// Delete a single row
export const deleteRow = mutation({
  args: { id: v.id("weeklyClients") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    await ctx.db.delete(args.id);
  },
});
