import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";

// ---- CATEGORIES ----
export const listCategories = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("categories").collect();
  },
});

export const createCategory = mutation({
  args: { name: v.string(), description: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });
    return await ctx.db.insert("categories", { name: args.name, description: args.description, createdBy: user._id });
  },
});

// ---- PRODUCTS ----
export const listProducts = query({
  args: { includeInactive: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    const products = args.includeInactive
      ? await ctx.db.query("products").collect()
      : await ctx.db.query("products").withIndex("by_active", (q) => q.eq("active", true)).collect();
    return products;
  },
});

export const getProduct = query({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    return await ctx.db.get(args.id);
  },
});

export const createProduct = mutation({
  args: {
    name: v.string(),
    code: v.string(),
    description: v.optional(v.string()),
    categoryId: v.optional(v.id("categories")),
    unit: v.union(v.literal("m2"), v.literal("cx"), v.literal("ml"), v.literal("un")),
    m2PerBox: v.optional(v.number()),
    costPrice: v.optional(v.number()),
    minStock: v.optional(v.number()),
    imageStorageId: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db.query("users").withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier)).unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const existingProducts = await ctx.db.query("products").withIndex("by_code", (q) => q.eq("code", args.code)).collect();
    const activeExisting = existingProducts.find((p) => p.active);
    if (activeExisting) throw new ConvexError({ message: "Código já cadastrado", code: "CONFLICT" });

    return await ctx.db.insert("products", {
      ...args,
      currentStock: 0,
      active: true,
      createdBy: user._id,
    });
  },
});

export const updateProduct = mutation({
  args: {
    id: v.id("products"),
    name: v.optional(v.string()),
    code: v.optional(v.string()),
    description: v.optional(v.string()),
    categoryId: v.optional(v.id("categories")),
    unit: v.optional(v.union(v.literal("m2"), v.literal("cx"), v.literal("ml"), v.literal("un"))),
    m2PerBox: v.optional(v.number()),
    costPrice: v.optional(v.number()),
    minStock: v.optional(v.number()),
    imageStorageId: v.optional(v.string()),
    active: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    await ctx.db.patch(id, rest);
  },
});

// Soft delete: marca produto como inativo sem remover do banco
// Pedidos e movimentações anteriores continuam referenciando o produto normalmente
export const deleteProduct = mutation({
  args: { id: v.id("products") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Não autenticado");
    await ctx.db.patch(args.id, { active: false });
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const getImageUrl = query({
  args: { storageId: v.string() },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});
