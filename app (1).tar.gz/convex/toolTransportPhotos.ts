import { mutation, query } from "./_generated/server";
import { v, ConvexError } from "convex/values";

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});

export const addPhoto = mutation({
  args: {
    transportId: v.id("toolTransports"),
    storageId: v.string(),
    type: v.union(v.literal("retirada"), v.literal("entrega"), v.literal("outros")),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    return await ctx.db.insert("toolTransportPhotos", {
      transportId: args.transportId,
      storageId: args.storageId,
      type: args.type,
      caption: args.caption,
      createdBy: user._id,
    });
  },
});

export const deletePhoto = mutation({
  args: { id: v.id("toolTransportPhotos") },
  handler: async (ctx, args) => {
    const photo = await ctx.db.get(args.id);
    if (!photo) throw new ConvexError({ message: "Foto não encontrada", code: "NOT_FOUND" });
    await ctx.storage.delete(photo.storageId as `${string}`);
    await ctx.db.delete(args.id);
  },
});

export const getPhotos = query({
  args: { transportId: v.id("toolTransports") },
  handler: async (ctx, args) => {
    const photos = await ctx.db
      .query("toolTransportPhotos")
      .withIndex("by_transport", (q) => q.eq("transportId", args.transportId))
      .order("desc")
      .collect();

    return await Promise.all(
      photos.map(async (photo) => {
        const url = await ctx.storage.getUrl(photo.storageId);
        const user = await ctx.db.get(photo.createdBy);
        return { ...photo, url, userName: user?.name ?? "—" };
      })
    );
  },
});
