"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";
import OpenAI from "openai";
import { internal } from "./_generated/api";

export const chat = action({
  args: {
    messages: v.array(
      v.object({
        role: v.union(v.literal("user"), v.literal("assistant")),
        content: v.string(),
      })
    ),
  },
  handler: async (ctx, args): Promise<string> => {
    const context = await ctx.runQuery(internal.dadaQueries.getSystemContext, {});

    const openai = new OpenAI({
      baseURL: "https://ai-gateway.hercules.app/v1",
      apiKey: process.env.HERCULES_API_KEY,
    });

    const systemPrompt = `Você é o Dadá, assistente operacional inteligente da Parket. Você tem acesso completo e em tempo real ao banco de dados do sistema.

Seu objetivo é responder perguntas sobre estoque, pedidos, clientes, entregas, fretes, materiais e movimentações de forma clara, objetiva e organizada.

DATA ATUAL: ${context.currentDate}

=== PRODUTOS EM ESTOQUE (${context.products.length} ativos) ===
${context.products.map((p) => `${p.name} (${p.code}): ${p.currentStock} ${p.unit}${p.m2PerBox ? ` | ${p.m2PerBox}m²/cx` : ""}${p.minStock != null ? ` | min:${p.minStock}` : ""}`).join("\n")}

=== CLIENTES (${context.clients.length}) ===
${context.clients.map((c) => `${c.name}${c.city ? ` - ${c.city}/${c.state}` : ""}${c.phone ? ` | ${c.phone}` : ""} | frete:${c.freightType}`).join("\n")}

=== PEDIDOS RECENTES ===
${context.recentOrders.map((o) => `${o.orderNumber} | ${o.clientName} | ${o.status} | ${o.createdAt.slice(0,10)} | frete:${o.freightType}${o.freightValue ? ` R$${o.freightValue}` : ""} | itens:[${o.items.map((i) => `${i.productName} ${i.quantity}${i.unit}${i.m2PerBox ? `(${(i.quantity*i.m2PerBox).toFixed(1)}m²)` : ""}`).join(", ")}]${o.deliveryAddress ? ` | endereço:${o.deliveryAddress}` : ""}${o.scheduledDate ? ` | previsto:${o.scheduledDate}` : ""}`).join("\n")}

=== MOVIMENTAÇÕES RECENTES ===
${context.recentMovements.map((m) => `${m.createdAt.slice(0,10)} | ${m.type} | ${m.productName} | ${m.quantity > 0 ? "+" : ""}${m.quantity}${m.unit} | antes:${m.quantityBefore} depois:${m.quantityAfter}${m.reason ? ` | ${m.reason}` : ""}${m.clientName ? ` | cliente:${m.clientName}` : ""}`).join("\n")}

=== RESUMO ===
Pedidos hoje: ${context.summary.ordersToday} | Este mês: ${context.summary.ordersThisMonth}
Pedidos pendentes (${context.summary.pendingOrdersCount}): ${context.summary.pendingOrders.map((o) => `${o.orderNumber} ${o.clientName} [${o.status}]`).join(", ")}
Produtos com estoque baixo (${context.summary.lowStockProducts.length}): ${context.summary.lowStockProducts.map((p) => `${p.name} ${p.currentStock}/${p.minStock}${p.unit}`).join(", ")}

STATUS: rascunho | confirmado | em_separacao | em_rota | entregue | cancelado
FRETES: interno=próprio | terceiro=terceirizado | retirada=cliente retira
UNIDADES: m2=metros² | cx=caixas | ml=metros lineares | un=unidades

REGRAS:
1. Responda sempre em português brasileiro
2. Seja objetivo e claro, use bullets e **negrito** para organizar
3. Inclua números, datas e status sempre que relevante
4. Calcule m² automaticamente (qty × m2PerBox) quando produto for em caixas
5. Se não encontrar o dado, diga claramente
6. Seja amigável e profissional como um funcionário especialista`;

    try {
      const response = await openai.chat.completions.create({
        model: "openai/gpt-5-mini",
        messages: [
          { role: "system", content: systemPrompt },
          ...args.messages,
        ],
      });

      return (
        response.choices[0]?.message?.content ??
        "Desculpe, não consegui processar sua pergunta. Tente novamente."
      );
    } catch (error) {
      if (error instanceof OpenAI.APIError) {
        throw new Error(`Erro na IA: ${error.message}`);
      }
      throw new Error("Erro ao processar pergunta. Tente novamente.");
    }
  },
});
