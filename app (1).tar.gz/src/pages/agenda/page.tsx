import { useEffect } from "react";
import { CalendarCheck, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";

const AGENDA_URL = "https://expedicaododia.onhercules.app/";

export default function AgendaPage() {
  // Abre automaticamente ao entrar na página
  useEffect(() => {
    window.open(AGENDA_URL, "_blank", "noopener,noreferrer");
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-center">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
        <CalendarCheck className="w-8 h-8 text-primary" />
      </div>
      <div>
        <h1 className="text-2xl font-bold">Agenda do Dia</h1>
        <p className="text-muted-foreground text-sm mt-1">
          A agenda abre automaticamente em uma nova aba.
        </p>
      </div>
      <Button
        className="cursor-pointer gap-2"
        onClick={() => window.open(AGENDA_URL, "_blank", "noopener,noreferrer")}
      >
        <ExternalLink className="w-4 h-4" />
        Abrir Agenda do Dia
      </Button>
      <p className="text-xs text-muted-foreground">
        Se não abriu automaticamente, clique no botão acima.
      </p>
    </div>
  );
}
