import { SignInButton } from "@/components/ui/signin.tsx";
import { Authenticated, Unauthenticated, AuthLoading } from "convex/react";
import { Skeleton } from "@/components/ui/skeleton.tsx";

export function LandingPage() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
      style={{
        background: "linear-gradient(135deg, oklch(0.20 0 0) 0%, oklch(0.32 0 0) 100%)"
      }}>
      
      <div className="mb-8">
        <img src="https://hercules-cdn.com/file_y00hXZQymkGbumtHalJjXq0e" alt="Parket" className="h-20 mx-auto mb-6" />
        <p className="text-lg text-white/70 max-w-md mx-auto mb-2">EXPEDIÇÃO

        </p>
        <p className="text-base font-semibold text-white/90 tracking-widest uppercase">
          "Pra nós, por nós"
        </p>
      </div>
      <SignInButton className="text-base px-8 py-3 h-auto text-white bg-zinc-900" />
    </div>);

}

export default function Index() {
  return (
    <>
      <AuthLoading>
        <div className="min-h-screen flex items-center justify-center">
          <Skeleton className="w-48 h-8" />
        </div>
      </AuthLoading>
      <Unauthenticated>
        <LandingPage />
      </Unauthenticated>
    </>);

}