import { useEffect } from "react";
import { Truck, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";

const FRETES_URL = "https://cartafreteparket.onhercules.app";

export default function FretesPage() {
  useEffect(() => {
    window.open(FRETES_URL, "_blank", "noopener,noreferrer");
  }, []);

  return (
    <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-center">
      <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
        <Truck className="w-8 h-8 text-primary" />
      </div>
      <div>
        <h1 className="text-2xl font-bold">Carta de Frete</h1>
        <p className="text-muted-foreground text-sm mt-1">
          A carta de frete abre automaticamente em uma nova aba.
        </p>
      </div>
      <Button
        className="cursor-pointer gap-2"
        onClick={() => window.open(FRETES_URL, "_blank", "noopener,noreferrer")}
      >
        <ExternalLink className="w-4 h-4" />
        Abrir Carta de Frete
      </Button>
      <p className="text-xs text-muted-foreground">
        Se não abriu automaticamente, clique no botão acima.
      </p>
    </div>
  );
}
